
import './App.css'
import { Header } from "@npm-workspace-demo/components"

function App() {

  return (
    <div className="App">
      <Header text="Hello World from app1" products="Web Products" />
    </div>
  )
}

export default App